## Install
```
- pullissue
pip3 install -i https://test.pypi.org/simple/ pullissue
```
## Using on Terminal
```
- load all issue
loadissue token
- load only repository
loadissue token username/repository
```
## Complete
```
file.csv will save in your Document
```