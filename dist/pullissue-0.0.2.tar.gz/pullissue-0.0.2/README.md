# Install PyGithub
```
pip3 install PyGithub
```
#load all issue
```
loadissue token
```
#load only repository
```
loadissue token username/repository
```
#Complete
```
file.csv will save in your Document
```