def showstring():
    print("extest")
    
def plus(a,b):
    print("A + B")

def re(s):
    return s
